import { join, normalize, sep } from "node:path";
export const getTypeScriptPackageJsonPath = (dirname = "") => {
    let nodeModulesPath;
    const normalizedPath = normalize(dirname);
    const parts = normalizedPath.split(sep);
    const nodeModulesIndex = parts.indexOf("node_modules");
    if (nodeModulesIndex !== -1) {
        nodeModulesPath = join(...parts.slice(0, nodeModulesIndex + 1));
    }
    else {
        nodeModulesPath = join(dirname, "node_modules");
    }
    return join(nodeModulesPath, "typescript", "package.json");
};
