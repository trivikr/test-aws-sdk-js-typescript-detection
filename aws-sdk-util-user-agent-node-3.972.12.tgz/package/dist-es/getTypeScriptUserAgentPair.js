import { readFile } from "node:fs/promises";
import { getTypeScriptPackageJsonPath } from "./getTypeScriptPackageJsonPath";
let tscVersion;
export const getTypeScriptUserAgentPair = async () => {
    if (tscVersion === null) {
        return undefined;
    }
    else if (tscVersion) {
        return ["md/tsc", tscVersion];
    }
    try {
        const packageJson = await readFile(getTypeScriptPackageJsonPath(__dirname), "utf-8");
        tscVersion = JSON.parse(packageJson).version;
        return ["md/tsc", tscVersion];
    }
    catch {
        tscVersion = null;
    }
};
