export declare const getCurrentDir: () => string;
