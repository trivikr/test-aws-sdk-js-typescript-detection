import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
export const getCurrentDir = () => {
    if (typeof __dirname !== "undefined") {
        return __dirname;
    }
    if (import.meta?.url) {
        return dirname(fileURLToPath(import.meta.url));
    }
    throw new Error("Cannot determine current directory");
};
